import requests
from datetime import datetime

def getTeamID(teamName):
    
    teamIds = {
        "Manchester United" : 33,
        "Newcastle" : 34,
        "Bournemouth" : 35,
        "Fulham" : 36,
        "Wolves" : 39,
        "Liverpool" : 40,
        "Southampton" : 41,
        "Arsenal" : 42,
        "Everton" : 45,
        "Leicester" : 46,
        "Tottenham" : 47,
        "West Ham" : 48,
        "Chelsea" : 49,
        "Manchester City" : 50,
        "Brighton" : 51,
        "Crystal Palace" : 52,
        "Brentford" : 55,
        "Leeds" : 63,
        "Nottingham Forest" : 65,
        "Aston Villa" : 66, 
    }
    
    return teamIds.get(teamName)

def getordinal(n: int):
    if 11 <= (n % 100) <= 13:
        suffix = 'th'
    else:
        suffix = ['th', 'st', 'nd', 'rd', 'th'][min(n % 10, 4)]
    return str(n) + suffix

def getLastOpponent(teamName, leagueId, season):
    
    endPoint = '/fixtures'
    params = {
        "timezone" : 'Europe/London',
        "league" : leagueId,
        "season" : season,
        "team" : getTeamID(teamName),
        "last" : 1
    }
    res = apiCall(endPoint, params)
    homeTeam = res['response'][0]['teams']['home'].get('name')
    awayTeam = res['response'][0]['teams']['away'].get('name')
    
    if teamName == homeTeam:
        if res['response'][0]['goals'].get('home') > res['response'][0]['goals'].get('away'):
            gameStatus = 'Won'
        elif  res['response'][0]['goals'].get('home') < res['response'][0]['goals'].get('away'):
            gameStatus = 'Lost'
        else:
            gameStatus = 'Draw'
    elif teamName == awayTeam:
        if res['response'][0]['goals'].get('away') > res['response'][0]['goals'].get('home'):
            gameStatus = 'Won'
        elif  res['response'][0]['goals'].get('away') < res['response'][0]['goals'].get('home'):
            gameStatus = 'Lost'
        else:
            gameStatus = 'Draw'
            
    dt = datetime.fromisoformat(res['response'][0]['fixture'].get('date'))
    date = f'{dt.day}/{dt.month}/{dt.year}'
    dayName = dt.strftime('%A')
    monthName = dt.strftime('%B')
    time = f'{dt.hour}:{dt.minute}'
    
    response = {
        "lastOpponentName" : ['home', homeTeam] if teamName != homeTeam else ['away',awayTeam],
        "lastGameDate" : date,
        "lastGameDayOrdinal" : getordinal(dt.day),
        "lastGameDayName" : dayName,
        "lastGameMonthName" : monthName,
        "lastGameTime" : time,
        "lastScoreHome" : res['response'][0]['goals'].get('home'),
        "lastScoreAway" : res['response'][0]['goals'].get('away'),
        "lastGameStatus" : gameStatus,
    }
    
    return response

def getLastScore(teamName, leagueId, season):
    
    endPoint = '/fixtures'
    params = {
        "timezone" : 'Europe/London',
        "league" : leagueId,
        "season" : season,
        "team" : getTeamID(teamName),
        "last" : 1
    }
    res = apiCall(endPoint, params)
    homeTeam = res['response'][0]['teams']['home'].get('name')
    awayTeam = res['response'][0]['teams']['away'].get('name')
    
    if teamName == homeTeam:
        if res['response'][0]['goals'].get('home') > res['response'][0]['goals'].get('away'):
            gameStatus = 'Won'
        elif  res['response'][0]['goals'].get('home') < res['response'][0]['goals'].get('away'):
            gameStatus = 'Lost'
        else:
            gameStatus = 'Draw'
    elif teamName == awayTeam:
        if res['response'][0]['goals'].get('away') > res['response'][0]['goals'].get('home'):
            gameStatus = 'Won'
        elif  res['response'][0]['goals'].get('away') < res['response'][0]['goals'].get('home'):
            gameStatus = 'Lost'
        else:
            gameStatus = 'Draw'
    
    dt = datetime.fromisoformat(res['response'][0]['fixture'].get('date'))
    date = f'{dt.day}/{dt.month}/{dt.year}'
    dayName = dt.strftime('%A')
    monthName = dt.strftime('%B')
    time = f'{dt.hour}:{dt.minute}'
               
    response = {
        "lastOpponentName" : ['home', homeTeam] if teamName != homeTeam else ['away',awayTeam],
        "lastGameDate" : date,
        "lastGameDayOrdinal" : getordinal(dt.day),
        "lastGameDayName" : dayName,
        "lastGameMonthName" : monthName,
        "lastGameTime" : time,
        "lastScoreHome" : res['response'][0]['goals'].get('home'),
        "lastScoreAway" : res['response'][0]['goals'].get('away'),
        "lastGameStatus" : gameStatus,
    }
    
    return response
        
def getLeaguePosition(teamName, leagueId, season):
    
    endPoint = '/standings'
    params = {
        "league" : leagueId,
        "season" : season,
        "team" : getTeamID(teamName),
    }
    res = apiCall(endPoint, params)
    
    response = {
        "leaguePosition" : res['response'][0]['league']['standings'][0][0].get('rank'),
        "leaguePositionOrdinal" : getordinal(res['response'][0]['league']['standings'][0][0].get('rank')),
        "winCount" : res['response'][0]['league']['standings'][0][0]['all'].get('win'),
        "loseCount" : res['response'][0]['league']['standings'][0][0]['all'].get('lose'),
        "DrawCount" : res['response'][0]['league']['standings'][0][0]['all'].get('draw'),
    }
    
    return response
  
def getmanager(teamName, leagueId, season):
    
    endPoint = '/coachs'
    params = {
        "team" : getTeamID(teamName),
    }
    res = apiCall(endPoint, params)
    
    response = {
        "firstName" : res['response'][0].get('firstname'),
        "lastName" : res['response'][0].get('lastname')
    }
    
    return response
      
def getNextGameDate(teamName, leagueId, season):
    
    endPoint = '/fixtures'
    params = {
        "timezone" : 'Europe/London',
        "league" : leagueId,
        "season" : season,
        "team" : getTeamID(teamName),
        "next" : 1
    }
    res = apiCall(endPoint, params)
    homeTeam = res['response'][0]['teams']['home'].get('name')
    awayTeam = res['response'][0]['teams']['away'].get('name')
    
    dt = datetime.fromisoformat(res['response'][0]['fixture'].get('date'))
    date = f'{dt.day}/{dt.month}/{dt.year}'
    dayName = dt.strftime('%A')
    monthName = dt.strftime('%B')
    time = f'{dt.hour}:{dt.minute}'

    response = {
        "nextOpponentName" : ['home', homeTeam] if teamName != homeTeam else ['away',awayTeam],
        "nextGameDate" : date,
        "nextGameDayOrdinal" : getordinal(dt.day),
        "nextGameDayName" : dayName,
        "nextGameMonthName" : monthName,
        "nextGameTime" : time,
    }
    
    return response
          
def getNextOpponent(teamName, leagueId, season):
    
    endPoint = '/fixtures'
    params = {
        "timezone" : 'Europe/London',
        "league" : leagueId,
        "season" : season,
        "team" : getTeamID(teamName),
        "next" : 1
    }
    res = apiCall(endPoint, params)
    homeTeam = res['response'][0]['teams']['home'].get('name')
    awayTeam = res['response'][0]['teams']['away'].get('name')
    
    dt = datetime.fromisoformat(res['response'][0]['fixture'].get('date'))
    date = f'{dt.day}/{dt.month}/{dt.year}'
    dayName = dt.strftime('%A')
    monthName = dt.strftime('%B')
    time = f'{dt.hour}:{dt.minute}'

    response = {
        "nextOpponentName" : ['home', homeTeam] if teamName != homeTeam else ['away',awayTeam],
        "nextGameDate" : date,
        "nextGameDayOrdinal" : getordinal(dt.day),
        "nextGameDayName" : dayName,
        "nextGameMonthName" : monthName,
        "nextGameTime" : time,
    }
    
    return response
   
def getnumGamesPlayed(teamName, leagueId, season):
    
    endPoint = '/teams/statistics'
    params = {
        "league" : leagueId,
        "season" : season,
        "team" : getTeamID(teamName),
    }
    res = apiCall(endPoint, params)
    
    response = {
        "totalCount" : res['response']['fixtures']['played'].get('total'),
        "winCount" : res['response']['fixtures']['wins'].get('total'),
        "loseCount" : res['response']['fixtures']['loses'].get('total'),
        "drawCount" : res['response']['fixtures']['draws'].get('total')
        }
    
    return response

def getPlayingNow(teamName, leagueId, season):
    
    endPoint = '/fixtures'
    params = {
        "timezone" : 'Europe/London',
        "league" : leagueId,
        "season" : season,
        "team" : getTeamID(teamName),
        "status" : 'LIVE-1H-HT-2H-ET-BT-P-SUSP-INT'
    }
    res = apiCall(endPoint, params)
    if res['response'] == []:
        response = getLastScore(teamName, leagueId, season)
        response.update(getNextOpponent(teamName, leagueId, season))
        response.update({"playingNow" : 'No'})
    else:
        response = {
            "playingNow" : 'Yes',
            "currentStatus" : res['response']['status'].get('long')
        }
    
    return response
          
def getWinLossRecord(teamName, leagueId, season):
    
    endPoint = '/standings'
    params = {
        "league" : leagueId,
        "season" : season,
        "team" : getTeamID(teamName),
    }
    res = apiCall(endPoint, params)
    
    response = {
        "leaguePosition" : res['response'][0]['league']['standings'][0][0].get('rank'),
        "leaguePositionOrdinal" : getordinal(res['response'][0]['league']['standings'][0][0].get('rank')),
        "totalCount" : res['response'][0]['league']['standings'][0][0]['all'].get('played'),
        "winCount" : res['response'][0]['league']['standings'][0][0]['all'].get('win'),
        "loseCount" : res['response'][0]['league']['standings'][0][0]['all'].get('lose'),
        "DrawCount" : res['response'][0]['league']['standings'][0][0]['all'].get('draw'),
    }
    
    return response

def apiCall(endPoint, params):
    
    url = 'https://v3.football.api-sports.io'
    headers = {
        'x-rapidapi-key': '38fdec909166f0c2892c4bca65085143',
        'x-rapidapi-host': 'v3.football.api-sports.io'
        }
    
    return requests.request("GET", url+endPoint, params=params, headers=headers).json()
    
def main(request):
    # CONSTANTS
    LEAGUEID = 39
    SEASON = 2022
    
    #Convert incoming request to JSON format
    request = request.get_json()
    
    #Get the Session Parameters value
    #date[0] = 'team'; Team name
    #data[1] = ['manager', 'leaguePosition', .....]; Information required
    data = request["sessionInfo"]["parameters"]
    teamName = data.get("team")
    info = data["info"]
    
    if info == "lastOpponent":
        response = getLastOpponent(teamName, LEAGUEID, SEASON)
    elif info == 'lastScore':
        response = getLastScore(teamName, LEAGUEID, SEASON)
    elif info == 'leaguePosition':
        response = getLeaguePosition(teamName, LEAGUEID, SEASON)
    elif info == 'manager':
        response = getmanager(teamName, LEAGUEID, SEASON)
    elif info == 'nextGameDate':
        response = getNextGameDate(teamName, LEAGUEID, SEASON)
    elif info == 'nextOpponent':
        response = getNextOpponent(teamName, LEAGUEID, SEASON)
    elif info == 'numGamesPlayed':
        response = getnumGamesPlayed(teamName, LEAGUEID, SEASON)
    elif info == 'playingNow':
        response = getPlayingNow(teamName, LEAGUEID, SEASON)
    elif info == 'winLossRecord':
        response = getWinLossRecord(teamName, LEAGUEID, SEASON)
    else:
        response = f"Info did not match condition {info}"
                
    print(response)

    # You can also use the google.cloud.dialogflowcx_v3.types.WebhookRequest protos instead of manually writing the json object
    # Please see https://googleapis.dev/python/dialogflow/latest/dialogflow_v2/types.html?highlight=webhookresponse#google.cloud.dialogflow_v2.types.WebhookResponse for an overview
    #res = {"fulfillment_response": {"messages": [{"text": {"text": [text]}}]}}

    res = {
    "sessionInfo" : {
        "parameters" : 
            response
            }
        }
    
    print(res)

    # Returns json
    return res
